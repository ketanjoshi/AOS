###########################################
Group Members: Ketan Joshi(kkj140030), Sneha Patil(svp140230), Rohini Yadav(rsy140030)
Course: CS6378.002
AOS Programming Assignment 2
###########################################

This folder contains the following:
1) launcher.sh : Script need to run to start the execution
2) cleanup.sh : Script to clean up the running processes
3) All source files (.java files)

Instructions to Run:
1) Go to the directory of the unzipped folder using 'cd {PATH_FOLDER_FILE_IS_UNZIPPED}' command.
2) Run the launcher.sh using command 'bash launcher.sh <Config-file-path> <net-id>'.
3) Class files and .out files will be generated inside 'rsy140030' folder.
4) Run the cleanup.sh using command 'bash cleanup.sh <Config-file-path> <net-id>'.



